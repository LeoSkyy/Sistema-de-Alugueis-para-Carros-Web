package br.com.leonardo.Sistema.de.Alugueis.para.Carros;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaDeAlugueisParaCarrosApplicationTests {

	@Test
	void contextLoads() {
	}

}
